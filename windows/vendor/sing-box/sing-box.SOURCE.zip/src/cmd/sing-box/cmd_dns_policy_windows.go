//go:build windows && with_gvisor

package main

import (
	"github.com/sagernet/sing-box/protocol/tun"
	"github.com/spf13/cobra"
)

func init() {
	mainCommand.AddCommand(&cobra.Command{Use: "windows-dns-policy", Hidden: true, Args: cobra.NoArgs,
		RunE: func(cmd *cobra.Command, args []string) error { return tun.RunWindowsDNSPolicy() }})
}
