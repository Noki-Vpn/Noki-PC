//go:build windows

package windivert

import (
	"encoding/binary"
	"fmt"
	"net/netip"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"unsafe"

	"golang.org/x/sys/windows"
)

type DNSPortLease struct {
	DNSPortBlock
	Info windows.WSAProtocolInfo `json:"info"`
}

type dnsPortReservation struct {
	DNSPortBlock
	socket windows.Handle
	token  uint64
}

type DNSPorts struct {
	mutex        sync.RWMutex
	closed       bool
	retained     bool
	reservations []dnsPortReservation
	servers      map[netip.Addr]bool
}

var activeDNSPorts atomic.Pointer[DNSPorts]

func NewDNSPorts(servers []netip.Addr) (*DNSPorts, error) {
	var data windows.WSAData
	if err := windows.WSAStartup(0x202, &data); err != nil {
		return nil, err
	}
	p := &DNSPorts{servers: make(map[netip.Addr]bool)}
	for _, server := range servers {
		p.servers[server.WithZone("")] = true
	}
	for _, ipv6 := range []bool{false, true} {
		for _, tcp := range []bool{false, true} {
			af, kind, protocol := int32(windows.AF_INET), int32(windows.SOCK_DGRAM), int32(windows.IPPROTO_UDP)
			if ipv6 {
				af = windows.AF_INET6
			}
			if tcp {
				kind = windows.SOCK_STREAM
				protocol = windows.IPPROTO_TCP
			}
			socket, err := windows.WSASocket(af, kind, protocol, nil, 0, windows.WSA_FLAG_OVERLAPPED|windows.WSA_FLAG_NO_HANDLE_INHERIT)
			if err != nil {
				_ = p.Close()
				return nil, err
			}
			request := [4]byte{0, 0, 0, 1}
			var result [16]byte
			var returned uint32
			err = windows.WSAIoctl(socket, 0x98000064, &request[0], 4, &result[0], 16, &returned, nil, 0)
			if err != nil {
				_ = windows.Closesocket(socket)
				_ = p.Close()
				return nil, fmt.Errorf("reserve core DNS ports: %w", err)
			}
			entry := dnsPortReservation{DNSPortBlock: DNSPortBlock{IPv6: ipv6, TCP: tcp, Start: binary.BigEndian.Uint16(result[:2]), Count: binary.LittleEndian.Uint16(result[2:4])}, socket: socket, token: binary.LittleEndian.Uint64(result[8:16])}
			if returned != 16 || entry.Start == 0 || entry.Count != 256 || uint32(entry.Start)+uint32(entry.Count) > 65536 || entry.token == 0 {
				_ = windows.Closesocket(socket)
				_ = p.Close()
				return nil, fmt.Errorf("invalid DNS port reservation")
			}
			p.reservations = append(p.reservations, entry)
		}
	}
	if !activeDNSPorts.CompareAndSwap(nil, p) {
		_ = p.Close()
		return nil, fmt.Errorf("system DNS port owner already active")
	}
	return p, nil
}

func (p *DNSPorts) Duplicate(pid uint32) ([]DNSPortLease, error) {
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	if p.closed {
		return nil, fmt.Errorf("DNS ports already closed")
	}
	result := make([]DNSPortLease, 0, len(p.reservations))
	for _, entry := range p.reservations {
		block := DNSPortLease{DNSPortBlock: entry.DNSPortBlock}
		if err := windows.WSADuplicateSocket(entry.socket, pid, &block.Info); err != nil {
			return nil, err
		}
		result = append(result, block)
	}
	return result, nil
}

func (p *DNSPorts) Block(ipv6, tcp bool) DNSPortBlock {
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	for _, entry := range p.reservations {
		if entry.IPv6 == ipv6 && entry.TCP == tcp {
			return entry.DNSPortBlock
		}
	}
	return DNSPortBlock{}
}

func (p *DNSPorts) Close() error {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	if p.retained {
		return nil
	}
	if p.closed {
		return nil
	}
	p.closed = true
	activeDNSPorts.CompareAndSwap(p, nil)
	var result error
	for _, entry := range p.reservations {
		if err := windows.Closesocket(entry.socket); err != nil {
			result = err
		}
	}
	p.reservations = nil
	_ = windows.WSACleanup()
	return result
}

// RetainUntilExit matches the desktop's one-core-process-per-connection lifecycle.
// The reservations must outlive every DROP duplicate, including a lost supervisor reply.
func (p *DNSPorts) RetainUntilExit() {
	p.mutex.Lock()
	p.retained = true
	p.mutex.Unlock()
}

// SystemDNSControl preserves the original socket/interface context; only kernel-reserved source ports bypass capture.
func SystemDNSControl(network, address string, conn syscall.RawConn) error {
	p := activeDNSPorts.Load()
	if p == nil {
		return nil
	}
	p.mutex.RLock()
	defer p.mutex.RUnlock()
	if p.closed {
		return fmt.Errorf("DNS ports already closed")
	}
	destination, err := netip.ParseAddrPort(address)
	if err != nil || destination.Port() != 53 || !p.servers[destination.Addr().WithZone("")] {
		return nil
	}
	for _, entry := range p.reservations {
		if entry.IPv6 != destination.Addr().Is6() || entry.TCP != strings.HasPrefix(network, "tcp") {
			continue
		}
		var controlErr error
		err = conn.Control(func(fd uintptr) {
			token := entry.token
			var returned uint32
			controlErr = windows.WSAIoctl(windows.Handle(fd), 0x98000066, (*byte)(unsafe.Pointer(&token)), 8, nil, 0, &returned, nil, 0)
		})
		if err != nil {
			return err
		}
		return controlErr
	}
	return fmt.Errorf("no reserved core DNS socket pool")
}

func HoldDNSPorts(blocks []DNSPortLease) ([]windows.Handle, error) {
	var data windows.WSAData
	if err := windows.WSAStartup(0x202, &data); err != nil {
		return nil, err
	}
	if len(blocks) != 4 {
		_ = windows.WSACleanup()
		return nil, fmt.Errorf("invalid DNS reservation set")
	}
	var sockets []windows.Handle
	for _, block := range blocks {
		if block.Start == 0 || block.Count != 256 || uint32(block.Start)+uint32(block.Count) > 65536 {
			ReleaseDNSPorts(sockets)
			return nil, fmt.Errorf("invalid DNS reservation range")
		}
		info := block.Info
		socket, err := windows.WSASocket(-1, -1, -1, &info, 0, windows.WSA_FLAG_OVERLAPPED|windows.WSA_FLAG_NO_HANDLE_INHERIT)
		if err != nil {
			ReleaseDNSPorts(sockets)
			return nil, err
		}
		sockets = append(sockets, socket)
	}
	return sockets, nil
}

func ReleaseDNSPorts(sockets []windows.Handle) {
	for _, socket := range sockets {
		_ = windows.Closesocket(socket)
	}
	_ = windows.WSACleanup()
}
