#ifndef NOKI_BYEDPI_H
#define NOKI_BYEDPI_H

int noki_parse_args(int *argc, char ***argv);
int noki_configure(void);
int noki_socket_egress(int fd);
int noki_protect_socket(int fd, const char *path);
int noki_take_listener(void);
int noki_ready(int fd);
int noki_keep_running(void);
void noki_request_stop(void);

#endif
