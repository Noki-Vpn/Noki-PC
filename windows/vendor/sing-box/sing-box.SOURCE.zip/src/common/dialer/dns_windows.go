//go:build windows

package dialer

import (
	"github.com/sagernet/sing-box/common/windivert"
	"syscall"
)

func systemDNSControl(network, address string, conn syscall.RawConn) error {
	return windivert.SystemDNSControl(network, address, conn)
}
