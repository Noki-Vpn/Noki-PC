//go:build !windows

package dialer

import "syscall"

func systemDNSControl(network, address string, conn syscall.RawConn) error { return nil }
