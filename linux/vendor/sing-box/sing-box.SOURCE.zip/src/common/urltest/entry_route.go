package urltest

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/netip"
	"strings"
	"time"

	C "github.com/sagernet/sing-box/constant"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
)

type entryRouteSelection struct {
	ExitNodeID *string `json:"exit_node_id"`
	Generation int64   `json:"generation"`
}

// SelectEntryRoute uses the actual authenticated outbound and fixed control targets.
func SelectEntryRoute(ctx context.Context, outbound N.Dialer, exitNodeID string, generation int64, enrollment bool) (uint16, error) {
	if generation <= 0 || (exitNodeID != "" && !validEntryRouteID(exitNodeID)) {
		return 0, fmt.Errorf("entry_route_invalid")
	}
	target := "entry-route.invalid:80"
	if wireguard, ok := outbound.(interface {
		Type() string
		PortAddresses() (netip.Addr, netip.Addr)
	}); ok && wireguard.Type() == C.TypeWireGuard {
		address, _ := wireguard.PortAddresses()
		if !address.Is4() || !netip.MustParsePrefix("10.240.0.0/16").Contains(address) || exitNodeID == "" {
			return 0, fmt.Errorf("entry_route_invalid")
		}
		gateway := address.As4()
		gateway[3] = 1
		target = net.JoinHostPort(netip.AddrFrom4(gateway).String(), "62101")
	} else if enrollment {
		return 0, fmt.Errorf("entry_route_invalid")
	}
	body, err := json.Marshal(entryRouteSelection{ExitNodeID: &exitNodeID, Generation: generation})
	if err != nil {
		return 0, err
	}
	started := time.Now()
	// Repeat a lost ACK using the original generation. Policy errors are final.
	attempts, timeout := 2, 2500*time.Millisecond
	if enrollment {
		attempts, timeout = 3, 3900*time.Millisecond
	}
	for attempt := 0; attempt < attempts; attempt++ {
		attemptCtx, cancel := context.WithTimeout(ctx, timeout)
		retry, requestErr := sendEntryRouteSelection(attemptCtx, outbound, target, body, exitNodeID, generation)
		cancel()
		if requestErr == nil {
			return uint16(max(1, time.Since(started).Milliseconds())), nil
		}
		err = requestErr
		if !retry || ctx.Err() != nil {
			break
		}
	}
	return 0, err
}

func sendEntryRouteSelection(ctx context.Context, outbound N.Dialer, target string, body []byte, exitNodeID string, generation int64) (bool, error) {
	transport := &http.Transport{
		DialContext: func(ctx context.Context, network, _ string) (net.Conn, error) {
			return outbound.DialContext(ctx, network, M.ParseSocksaddr(target))
		},
		DisableKeepAlives:      true,
		MaxResponseHeaderBytes: 4096,
	}
	defer transport.CloseIdleConnections()
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, "http://"+target+"/entry/route", bytes.NewReader(body))
	if err != nil {
		return false, err
	}
	request.Header.Set("Content-Type", "application/json")
	response, err := transport.RoundTrip(request)
	if err != nil {
		return true, err
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK {
		return false, fmt.Errorf("entry_route_status_%d", response.StatusCode)
	}
	data, err := io.ReadAll(io.LimitReader(response.Body, 513))
	if err != nil {
		return true, err
	}
	var ack entryRouteSelection
	if len(data) > 512 || json.Unmarshal(data, &ack) != nil || ack.ExitNodeID == nil || *ack.ExitNodeID != exitNodeID || ack.Generation != generation {
		return false, fmt.Errorf("entry_route_ack_mismatch")
	}
	return false, nil
}

func validEntryRouteID(id string) bool {
	if len(id) != 36 {
		return false
	}
	for index, value := range id {
		if index == 8 || index == 13 || index == 18 || index == 23 {
			if value != '-' {
				return false
			}
		} else if !strings.ContainsRune("0123456789abcdef", value) {
			return false
		}
	}
	return true
}
