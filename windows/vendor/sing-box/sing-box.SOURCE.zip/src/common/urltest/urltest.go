package urltest

import (
	"context"
	"crypto/tls"
	"io"
	"net"
	"net/http"
	"net/url"
	"sync"
	"time"

	"github.com/sagernet/sing-box/adapter"
	C "github.com/sagernet/sing-box/constant"
	"github.com/sagernet/sing/common"
	E "github.com/sagernet/sing/common/exceptions"
	M "github.com/sagernet/sing/common/metadata"
	N "github.com/sagernet/sing/common/network"
	"github.com/sagernet/sing/common/ntp"
	"github.com/sagernet/sing/common/observable"
)

type HistoryStorage struct {
	access       sync.RWMutex
	delayHistory map[string]*adapter.URLTestHistory
	updateHooks  []*observable.Subscriber[struct{}]
}

func NewHistoryStorage() *HistoryStorage {
	return &HistoryStorage{
		delayHistory: make(map[string]*adapter.URLTestHistory),
	}
}

func (s *HistoryStorage) AddUpdateHook(hook *observable.Subscriber[struct{}]) {
	s.access.Lock()
	defer s.access.Unlock()
	s.updateHooks = append(s.updateHooks, hook)
}

func (s *HistoryStorage) NotifyUpdated() {
	s.access.RLock()
	defer s.access.RUnlock()
	s.notifyUpdated()
}

func (s *HistoryStorage) LoadURLTestHistory(tag string) *adapter.URLTestHistory {
	if s == nil {
		return nil
	}
	s.access.RLock()
	defer s.access.RUnlock()
	return s.delayHistory[tag]
}

func (s *HistoryStorage) DeleteURLTestHistory(tag string) {
	s.access.Lock()
	delete(s.delayHistory, tag)
	s.notifyUpdated()
	s.access.Unlock()
}

func (s *HistoryStorage) StoreURLTestHistory(tag string, history *adapter.URLTestHistory) {
	s.access.Lock()
	s.delayHistory[tag] = history
	s.notifyUpdated()
	s.access.Unlock()
}

func (s *HistoryStorage) notifyUpdated() {
	for _, updateHook := range s.updateHooks {
		updateHook.Emit(struct{}{})
	}
}

func (s *HistoryStorage) Close() error {
	s.access.Lock()
	defer s.access.Unlock()
	s.updateHooks = nil
	return nil
}

func URLTest(ctx context.Context, link string, detour N.Dialer) (uint16, error) {
	multiplexOutbound, isMultiplexOutbound := common.Cast[adapter.OutboundWithMultiplex](detour)
	if isMultiplexOutbound && multiplexOutbound.MultiplexEnabled() {
		_, err := urlTest(ctx, link, detour, false)
		if err != nil {
			return 0, err
		}
	}
	return urlTest(ctx, link, detour, false)
}

func MeasureDelay(ctx context.Context, link string, detour N.Dialer) (uint16, error) {
	return urlTest(ctx, link, detour, true)
}

func urlTest(ctx context.Context, link string, detour N.Dialer, measurement bool) (t uint16, err error) {
	if link == "" && !measurement {
		link = "https://www.gstatic.com/generate_204"
	}
	linkURL, err := url.Parse(link)
	if err != nil {
		return
	}
	if measurement && (linkURL.Hostname() == "" || (linkURL.Scheme != "http" && linkURL.Scheme != "https")) {
		return 0, E.New("invalid measurement URL")
	}
	hostname := linkURL.Hostname()
	port := linkURL.Port()
	if port == "" {
		switch linkURL.Scheme {
		case "http":
			port = "80"
		case "https":
			port = "443"
		}
	}

	start := time.Now()
	instance, err := detour.DialContext(ctx, "tcp", M.ParseSocksaddrHostPortStr(hostname, port))
	if err != nil {
		return
	}
	defer instance.Close()
	if N.NeedHandshakeForWrite(instance) {
		start = time.Now()
	}
	method := http.MethodHead
	if measurement {
		method = http.MethodGet
	}
	req, err := http.NewRequest(method, link, nil)
	if err != nil {
		return
	}
	var dialAccess sync.Mutex
	firstDial := true
	client := http.Client{
		Transport: &http.Transport{
			DialContext: func(_ context.Context, network, addr string) (net.Conn, error) {
				if measurement {
					dialAccess.Lock()
					first := firstDial
					firstDial = false
					dialAccess.Unlock()
					if !first {
						// HTTP transport may detach the dial context; keep the caller's total deadline.
						return detour.DialContext(ctx, network, M.ParseSocksaddr(addr))
					}
					if err := ctx.Err(); err != nil {
						return nil, err
					}
				}
				return instance, nil
			},
			TLSClientConfig: &tls.Config{
				Time:    ntp.TimeFuncFromContext(ctx),
				RootCAs: adapter.RootPoolFromContext(ctx),
			},
		},
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			return http.ErrUseLastResponse
		},
		Timeout: C.TCPTimeout,
	}
	defer client.CloseIdleConnections()
	resp, err := client.Do(req.WithContext(ctx))
	if err != nil {
		return
	}
	if measurement {
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusNoContent {
			return 0, E.New("measurement returned HTTP status ", resp.StatusCode)
		}
		const maxBody = 256 * 1024
		length, readErr := io.Copy(io.Discard, io.LimitReader(resp.Body, maxBody+1))
		if readErr != nil {
			return 0, readErr
		}
		if length > maxBody {
			return 0, E.New("measurement response body exceeds limit")
		}
		if err := ctx.Err(); err != nil {
			return 0, err
		}
		t = uint16(time.Since(start) / time.Millisecond)
		if t == 0 {
			t = 1
		}
		return t, nil
	}
	resp.Body.Close()
	if IsUnifiedDelayFromContext(ctx) {
		second := time.Now()
		resp, err = client.Do(req)
		if err != nil {
			return
		}
		resp.Body.Close()
		start = second
	}
	t = uint16(time.Since(start) / time.Millisecond)
	return
}
