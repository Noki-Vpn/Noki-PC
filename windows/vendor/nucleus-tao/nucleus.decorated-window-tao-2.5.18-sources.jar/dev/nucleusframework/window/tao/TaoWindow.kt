@file:Suppress("MagicNumber")

package dev.nucleusframework.window.tao

import androidx.compose.runtime.mutableStateOf
import dev.nucleusframework.core.runtime.Platform
import dev.nucleusframework.window.tao.dispatch.TaoMainDispatcher
import dev.nucleusframework.window.tao.ffi.NativeTaoBridge
import dev.nucleusframework.window.tao.ffi.NativeTaoLinuxTouchBridge
import dev.nucleusframework.window.tao.ffi.NativeTaoMacOsDecoBridge
import dev.nucleusframework.window.tao.ffi.NativeTaoWindowsDecoBridge
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean
import java.util.logging.Logger
import dev.nucleusframework.window.tao.event.AWT_PIXEL_TO_ROTATION as SHARED_AWT_PIXEL_TO_ROTATION
import dev.nucleusframework.window.tao.event.MACOS_AWT_SCROLL_AMOUNT as SHARED_MACOS_AWT_SCROLL_AMOUNT

/**
 * Phase 2 handle to a window owned by the Tao event loop.
 *
 * Native commands are thread-safe: they post commands as user events to the
 * event loop, which executes them on the platform event-loop thread. Listener
 * registration is also safe to call across threads.
 */
@Suppress("TooManyFunctions", "LargeClass")
public class TaoWindow internal constructor(
    public val handle: Long,
    isResizable: Boolean = true,
    /**
     * `true` when the window was created as a popup overlay of another window
     * (`openWindow(popupOf = …)` — GTK_WINDOW_POPUP, mapped as a `wl_subsurface`
     * on Wayland). The Linux host disables Mesa's FIFO frame pacing for these:
     * their EGL child is a subsurface of GDK's own (synchronized) subsurface,
     * so FIFO commits stay cached compositor-side and the pending
     * `wp_commit_timer_v1` timestamp is never consumed — the next
     * `set_timestamp` then kills the client with a fatal
     * "Commit already has timestamp" protocol error.
     */
    public val isPopup: Boolean = false,
    /**
     * Handle of the [popupOf] parent when [isPopup] is true (Linux only).
     * Used to resolve the parent's CSD content origin when positioning this
     * window as a Wayland `wl_subsurface`.
     */
    internal val popupParentHandle: Long = 0L,
    /**
     * `true` when the window asked for an X11 surface through
     * `openWindow(forceX11 = true)` (Linux only). Kept so [show] can report a
     * request the native side could not honour.
     */
    internal val requestedX11: Boolean = false,
) {
    // Snapshot-backed so Compose consumers (WindowControls*, resize hit-test
    // gating) recompose when resizability changes at runtime — the AWT
    // backends get the same reactivity from DecoratedWindowState (#260).
    private val resizableState = mutableStateOf(isResizable)

    /**
     * `true` when the window can currently be resized by the user. Initially
     * the `resizable` flag the window was created with; tracks runtime
     * [setResizable] calls. Surfaced to Compose so [WindowControlsLinux] /
     * [WindowControlsWindows] can hide the maximize button on non-resizable
     * windows (matches the `decorated-window-jni` behaviour).
     */
    public val isResizable: Boolean
        get() = resizableState.value

    /** Enables/disables user resizing (borders, maximize) at runtime. */
    public fun setResizable(resizable: Boolean) {
        if (resizableState.value == resizable) return
        resizableState.value = resizable
        NativeTaoBridge.nativeSetResizable(handle, resizable)
    }

    @Volatile
    private var readyListener: ((Int, Int) -> Unit)? = null

    // Multi-cast: the imperative `openDecoratedWindow` registers a listener
    // for host-rendering, and the @Composable `DecoratedWindow` adds another
    // for state-sync. They must coexist.
    private val resizedListeners = CopyOnWriteArrayList<(Int, Int) -> Unit>()
    private val movedListeners = CopyOnWriteArrayList<(Int, Int) -> Unit>()
    private val minimizedListeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    @Volatile
    public var isMinimized: Boolean = false
        private set

    @Volatile
    private var scaleFactorListener: ((Float) -> Unit)? = null

    @Volatile
    private var closeRequestedListener: (() -> Unit)? = null

    /**
     * Fires synchronously at the start of [requestClose] — before the native
     * destroy — so the host can present an opaque last frame (backdrop
     * teardown) while the window and its GL surface are still alive.
     * Multi-cast: the Windows host registers prepare, and e2e probes may add
     * their own. Not invoked from [requestUserClose] / [onCloseRequested]:
     * that path is cancelable ("Save before quit?") and must not permanently
     * kill Mica.
     */
    private val prepareCloseListeners = CopyOnWriteArrayList<() -> Unit>()

    private val destroyedListeners = CopyOnWriteArrayList<() -> Unit>()

    @Volatile
    private var redrawListener: (() -> Unit)? = null

    private var dragWindowListener: (() -> Unit)? = null

    // Coalesces concurrent `requestRedraw` calls into one pending native request:
    // tao on Linux only drains one entry from its `draws` channel per event-loop
    // iteration, but Compose readily produces multiple invalidations per frame
    // (FlushingDispatcher.dispatch, scene invalidate, onResized…). Without
    // coalescing, the channel is flooded by the active window's redraws and
    // requests for any *other* window (e.g. a freshly-opened DecoratedDialog)
    // get buried — observable as a dialog stuck on its initial frame and
    // displaying black. Cleared in `dispatch(REDRAW_REQUESTED)`, just before
    // the listener runs, so a redraw posted *during* render still gets through.
    private val redrawPending = AtomicBoolean(false)

    // Startup white-flash workaround: the themed WM_ERASEBKGND fill is armed on
    // show() and disabled once — on the first native redraw after show. Gating
    // on this flag keeps the disable off the per-frame redraw path.
    private var startupEraseActive = false
    private val focusListeners = CopyOnWriteArrayList<(Boolean) -> Unit>()

    @Volatile
    private var willHideListener: (() -> Unit)? = null
    private var shownListener: (() -> Unit)? = null

    @Volatile
    private var sizeMoveListener: ((Boolean) -> Unit)? = null
    private var pointerMoveListener: ((Int, Int) -> Unit)? = null

    @Volatile
    private var pointerExitedListener: (() -> Unit)? = null

    @Volatile
    private var pointerButtonListener: ((Int, Boolean) -> Unit)? = null

    @Volatile
    private var pointerScrollListener: ((TaoPointerScrollEvent) -> Unit)? = null

    @Volatile
    private var trackpadGestureListener: TrackpadGestureListener? = null

    @Volatile
    private var touchInputListener: TouchInputListener? = null

    @Volatile
    private var keyListener: KeyEventListener? = null

    @Volatile
    internal var modifierState: Int = 0
        private set

    /**
     * macOS-only trackpad gesture listener. Receives raw magnify / rotate /
     * smart-magnify deltas already reshaped by the Rust bridge — see
     * [NativeTaoBridge.EventCallback.onTrackpadGesture] for the wire format.
     */
    public fun interface TrackpadGestureListener {
        public fun onGesture(
            kind: Int, // TaoTrackpadGesture.MAGNIFY | ROTATE | SMART_MAGNIFY
            phase: Int, // TaoTrackpadPhase.BEGAN | CHANGED | ENDED | CANCELLED
            xFixed: Int, // physical pixels × 1024, view-relative, top-left
            yFixed: Int,
            valueFixed: Int, // delta × 10000 (ratio for magnify, degrees for rotate)
        )
    }

    /**
     * Windows-only touchscreen listener (Tao emits `WindowEvent::Touch` via
     * WM_POINTER / WM_TOUCH). One callback per finger update — the host is
     * responsible for aggregating the active set before issuing a Compose
     * `sendPointerEvent`. See [NativeTaoBridge.EventCallback.onTouchInput].
     *
     * Linux uses a separate per-window bridge ([NativeTaoLinuxTouchBridge])
     * because GTK 3 doesn't surface touch through Tao's event stream.
     */
    public fun interface TouchInputListener {
        public fun onTouch(
            phase: Int, // TaoTouchEvent.PRESS | MOVE | RELEASE | CANCEL
            id: Long, // OS-assigned finger id
            xFixed: Int, // physical pixels × 1024
            yFixed: Int,
            forceFixed: Int, // pressure × 10000, or TaoTouchEvent.FORCE_UNKNOWN
        )
    }

    /** Receives keyboard events shaped like AWT for direct consumption by Compose. */
    public fun interface KeyEventListener {
        public fun onKey(
            type: Int, // TaoEventCode.KEY_DOWN | KEY_UP
            vkCode: Int, // AWT KeyEvent.VK_*
            keyLocation: Int, // AWT KeyEvent.KEY_LOCATION_*
            modifiers: Int, // TaoModifierMask bitmask
            codePoint: Int, // First Unicode scalar of typed text (or 0)
        )
    }

    public fun setTitle(title: String) {
        NativeTaoBridge.nativeSetTitle(handle, title)
    }

    public fun requestRedraw() {
        if (!redrawPending.compareAndSet(false, true)) return
        NativeTaoBridge.nativeRequestRedraw(handle)
    }

    /**
     * Clears the [redrawPending] coalescing latch and re-issues a request.
     *
     * For callers returning from an OS modal loop (`DoDragDrop`, and anything
     * else that runs its own message pump): a redraw requested just before or
     * during that loop latches `redrawPending` true, and the matching
     * REDRAW_REQUESTED can be swallowed by the nested pump. The latch then
     * suppresses *every* later [requestRedraw] and the window silently stops
     * painting — until an unrelated event happens to clear it, which is why the
     * symptom reads as "frozen until I click on it again" (the FOCUSED branch
     * in [dispatch] clears the same latch for the same reason).
     *
     * No frame is lost by calling this: a genuinely in-flight redraw just
     * yields one extra, idempotent request.
     */
    internal fun resetRedrawLatch() {
        redrawPending.set(false)
        requestRedraw()
    }

    public fun requestClose() {
        // Actual destroy path (not the cancelable close-*request*). Present an
        // opaque themed frame first: a live backdrop's translucent clear would
        // composite towards black in the close animation. The host listener
        // also flips the Compose clear path; the native fallback covers raw
        // TaoWindow usage with no host attached.
        if (prepareCloseListeners.isEmpty()) {
            if (Platform.Current == Platform.Windows && NativeTaoWindowsDecoBridge.isLoaded) {
                val hwnd = NativeTaoBridge.nativeHwndHandle(handle)
                if (hwnd != 0L) NativeTaoWindowsDecoBridge.nativePrepareClose(hwnd)
            }
        } else {
            for (listener in prepareCloseListeners) listener.invoke()
        }
        NativeTaoBridge.nativeRequestClose(handle)
    }

    /**
     * Fires the [onCloseRequested] listener as if the OS had emitted a close
     * event (clicking native X, Alt+F4, etc.). Use this from custom UI like
     * the title-bar close button so the user's `onCloseRequest` callback runs
     * and gets a chance to call `exitApplication()` — bypassing it via
     * [requestClose] destroys the window but leaves the event loop running.
     *
     * Does **not** tear down a [dev.nucleusframework.window.WindowsBackdrop]:
     * the request is cancelable, and a permanent native revert here would leave
     * a still-composed backdrop dead after "Cancel". The opaque last frame is
     * prepared in [requestClose] once destroy is confirmed.
     */
    public fun requestUserClose() {
        closeRequestedListener?.invoke()
    }

    /** Starts a native window drag — call synchronously during a mouse press. */
    public fun dragWindow() {
        // Notify listeners BEFORE the grab: the compositor swallows the button
        // release once the interactive move starts, so the host needs to reset
        // its Compose pointer state to avoid getting stuck "pressed".
        dragWindowListener?.invoke()
        NativeTaoBridge.nativeDragWindow(handle)
    }

    /** Fires synchronously when [dragWindow] is invoked (compositor move grab). */
    public fun onDragWindow(block: () -> Unit) {
        dragWindowListener = block
    }

    // ── Windows touch title-bar drag (driven from raw Tao touch events) ────
    // The Compose-side `pointerInput` modifier captures the press, then
    // [beginWindowsTitleBarTouchDrag] arms a per-window drag state. Subsequent
    // touch samples are routed here from [TaoComposeSceneHostWindows.onTouchInput]
    // BEFORE Compose's pointer dispatch, so the window-move pipeline keeps
    // running even if Compose pointer routing breaks (e.g. after the layout
    // size changes mid-drag-from-maximized).

    @Volatile
    private var windowsTitleBarTouchDrag: WindowsTitleBarTouchDrag? = null

    internal fun beginWindowsTitleBarTouchDrag(
        touchId: Long,
        hwnd: Long,
        startScreenX: Int,
        startScreenY: Int,
        startOuterX: Long,
        startOuterY: Long,
        maximized: Boolean,
    ) {
        if (Platform.Current != Platform.Windows ||
            !NativeTaoWindowsDecoBridge.isLoaded ||
            hwnd == 0L
        ) {
            return
        }
        windowsTitleBarTouchDrag =
            WindowsTitleBarTouchDrag(
                touchId = touchId,
                hwnd = hwnd,
                startScreenX = startScreenX,
                startScreenY = startScreenY,
                startOuterX = startOuterX,
                startOuterY = startOuterY,
                wasMaximized = maximized,
                prepared = !maximized,
                lastScreenX = startScreenX,
                lastScreenY = startScreenY,
            )
    }

    /**
     * Aborts any in-flight Windows touch title-bar drag. Called by the
     * Compose double-tap handler after it toggles maximize, so a small
     * finger jitter between the second press and its release doesn't run
     * `nativeSetWindowOuterPositionPx` against the now-maximized HWND.
     */
    internal fun cancelWindowsTitleBarTouchDrag() {
        windowsTitleBarTouchDrag = null
    }

    internal fun updateWindowsTitleBarTouchDrag(
        phase: Int,
        touchId: Long,
        xClientPx: Float,
        yClientPx: Float,
    ) {
        val drag = windowsTitleBarTouchDrag ?: return
        if (drag.touchId != touchId) return

        if (phase == TaoTouchEvent.CANCEL) {
            windowsTitleBarTouchDrag = null
            return
        }
        val screen =
            NativeTaoWindowsDecoBridge.nativeClientToScreen(
                drag.hwnd,
                xClientPx.toInt(),
                yClientPx.toInt(),
            )
        if (screen == null || screen.size != 2) {
            if (phase == TaoTouchEvent.RELEASE) {
                windowsTitleBarTouchDrag = null
            }
            return
        }
        drag.lastScreenX = screen[0]
        drag.lastScreenY = screen[1]

        if (phase == TaoTouchEvent.RELEASE) {
            windowsTitleBarTouchDrag = null
            return
        }
        if (phase != TaoTouchEvent.MOVE) return

        if (drag.wasMaximized && !drag.prepared) {
            val dx = screen[0] - drag.startScreenX
            val dy = screen[1] - drag.startScreenY
            if (kotlin.math.abs(dx) < WINDOWS_TOUCH_DRAG_THRESHOLD_PX &&
                kotlin.math.abs(dy) < WINDOWS_TOUCH_DRAG_THRESHOLD_PX
            ) {
                return
            }
            val rect =
                NativeTaoWindowsDecoBridge.nativePrepareTitleBarTouchDrag(
                    drag.hwnd,
                    screen[0],
                    screen[1],
                    drag.startScreenX,
                    drag.startScreenY,
                )
            if (rect == null || rect.size != 4) {
                windowsTitleBarTouchDrag = null
                return
            }
            drag.startOuterX = rect[0]
            drag.startOuterY = rect[1]
            drag.startScreenX = screen[0]
            drag.startScreenY = screen[1]
            drag.wasMaximized = false
            drag.prepared = true
            requestRedraw()
            return
        }

        val targetX = drag.startOuterX + (screen[0] - drag.startScreenX)
        val targetY = drag.startOuterY + (screen[1] - drag.startScreenY)
        NativeTaoWindowsDecoBridge.nativeSetWindowOuterPositionPx(
            drag.hwnd,
            targetX.toInt(),
            targetY.toInt(),
        )
        requestRedraw()
    }

    /**
     * Returns the underlying native window handle for the current platform:
     *  - Windows: HWND as a `Long` (0 if unavailable). Suitable for
     *    `FileKitDialogParent.windows`.
     *  - macOS: NSView pointer as a `Long` — the AppKit subview hosting the
     *    Compose surface. For dialog/sheet parenting use [nsWindowHandle]
     *    instead; an NSView is not a valid `beginSheetModalForWindow:` parent.
     *  - Linux: returns 0. Prefer [x11WindowId] (X11 portal parent) or
     *    [exportXdgForeignHandle] (Wayland portal parent) — a raw `wl_surface*`
     *    is not a valid XDG Desktop Portal parent.
     *
     * Intended for cross-module integration (e.g. taskbar, notifications) that
     * need to address the OS window directly without going through Tao APIs.
     */
    public val nativeHandle: Long
        get() =
            when (Platform.Current) {
                Platform.Windows -> NativeTaoBridge.nativeHwndHandle(handle)
                Platform.MacOS -> NativeTaoBridge.nativeNsViewHandle(handle)
                else -> 0L
            }

    /**
     * macOS only: the owning `NSWindow*` for native dialog parenting
     * (`beginSheetModalForWindow:`, future FileKit sheet parents).
     * `null` when not on macOS, not yet realized, or the native bridge is
     * unavailable.
     *
     * Distinct from [nativeHandle], which is the Compose host `NSView*` on
     * macOS. Borrow the pointer for the duration of the picker call only —
     * FileKit-style adapters do not extend its lifetime.
     *
     * ### Adapter sketch
     * ```kotlin
     * // Once FileKit accepts an NSWindow parent:
     * // window.nsWindowHandle?.let { FileKitDialogParent.macos(it) }
     * ```
     */
    public val nsWindowHandle: Long?
        get() {
            if (Platform.Current != Platform.MacOS || !NativeTaoBridge.isLoaded) return null
            return NativeTaoBridge.nativeNsWindowHandle(handle).takeIf { it != 0L }
        }

    /**
     * Linux/X11 only: the window's XID for XDG Desktop Portal parenting
     * (`x11:<hex>` / `FileKitDialogParent.x11`). `null` when not on X11, not
     * yet realized, or the native bridge is unavailable.
     *
     * Prefer [xdgPortalParent] when the caller only needs a portal string and
     * should work on both X11 and Wayland.
     */
    public val x11WindowId: Long?
        get() {
            if (Platform.Current != Platform.Linux || !NativeTaoBridge.isLoaded) return null
            val handles = NativeTaoBridge.nativeLinuxHandles(handle) ?: return null
            // [kind, display, nativeWindow] — kind 1 = Xlib, slot 2 = XID.
            if (handles.size < 3 || handles[0] != 1L) return null
            val xid = handles[2]
            return xid.takeIf { it in 1L..0xffff_ffffL }
        }

    /**
     * Linux/X11 only: portal `parent_window` value `x11:<lowercase-hex-xid>`.
     * `null` when [x11WindowId] is unavailable.
     */
    public val x11PortalParent: String?
        get() = x11WindowId?.let { xid -> "x11:${xid.toString(radix = 16)}" }

    /**
     * Linux/Wayland only: export this window via `xdg_foreign` for XDG Desktop
     * Portal dialog parenting (FileKit `FileKitDialogParent.wayland`, portal
     * `parent_window = wayland:<handle>`).
     *
     * Blocks until the compositor issues the token or [timeoutMs] elapses.
     * Returns `null` on X11, when the window is not realized, or on failure.
     * The returned [XdgForeignExport] must stay open until portal dialogs that
     * borrow [XdgForeignExport.handle] complete — close it afterward.
     *
     * Prefer [xdgPortalParent] for a backend-agnostic Linux parent.
     *
     * Safe to call from a worker thread or the Tao main thread (the native
     * side nests the GLib main context when already on the GTK thread).
     */
    public fun exportXdgForeignHandle(timeoutMs: Long = 5_000L): XdgForeignExport? {
        if (Platform.Current != Platform.Linux || !NativeTaoBridge.isLoaded) return null
        val token =
            NativeTaoBridge.nativeLinuxExportXdgForeignHandle(
                handle,
                timeoutMs.coerceIn(1L, Int.MAX_VALUE.toLong()).toInt(),
            ) ?: return null
        if (token.isEmpty()) return null
        return XdgForeignExport(token, handle)
    }

    /**
     * Linux only: resolve the XDG Desktop Portal parent for this window.
     *
     * - **X11 / XWayland** → [XdgPortalParent.X11] with the live XID (no
     *   lifetime object; valid while the window is mapped).
     * - **Wayland** → [XdgPortalParent.Wayland] wrapping an [XdgForeignExport]
     *   that must stay open until portal dialogs complete.
     *
     * Returns `null` when the window is not realized, the bridge is missing,
     * or Wayland export times out. [timeoutMs] only applies to the Wayland path.
     */
    public fun xdgPortalParent(timeoutMs: Long = 5_000L): XdgPortalParent? {
        if (Platform.Current != Platform.Linux || !NativeTaoBridge.isLoaded) return null
        x11WindowId?.let { return XdgPortalParent.X11(it) }
        val export = exportXdgForeignHandle(timeoutMs) ?: return null
        return XdgPortalParent.Wayland(export)
    }

    public val isMaximized: Boolean
        get() = NativeTaoBridge.nativeIsMaximized(handle)

    /**
     * Outer (decoration-inclusive) window bounds as `[x, y, width, height]` in
     * physical screen pixels with a top-left origin, or `null` while the native
     * window isn't realized / the platform bridge is unavailable. All three
     * platform bridges share the Win32 `GetWindowRect` convention.
     */
    public fun outerBoundsPx(): LongArray? =
        when (Platform.Current) {
            Platform.Windows -> {
                if (!NativeTaoWindowsDecoBridge.isLoaded) {
                    null
                } else {
                    NativeTaoBridge
                        .nativeHwndHandle(handle)
                        .takeIf { it != 0L }
                        ?.let { NativeTaoWindowsDecoBridge.nativeGetWindowRect(it) }
                }
            }
            Platform.MacOS -> {
                if (!NativeTaoMacOsDecoBridge.isLoaded) {
                    null
                } else {
                    nativeHandle
                        .takeIf { it != 0L }
                        ?.let { NativeTaoMacOsDecoBridge.nativeGetWindowRect(it) }
                }
            }
            Platform.Linux -> NativeTaoBridge.nativeLinuxGetWindowRect(handle)
            else -> null
        }

    /** The window's current monitor scale factor (1.0 on non-HiDPI displays). */
    public val scaleFactor: Float
        get() = NativeTaoBridge.nativeScaleFactor(handle).coerceAtLeast(1) / 1000f

    /**
     * Linux/GTK only: true when the compositor has tiled/snapped the window to a
     * screen edge (Aero Snap). Always `false` on Windows/macOS (the native lib
     * returns `false` outside the GTK backend). Used to drop the Compose-drawn
     * rounded corners when snapped, matching native client-side decorations.
     */
    public val isTiled: Boolean
        get() = NativeTaoBridge.nativeIsTiled(handle)

    public val isFullscreen: Boolean
        get() {
            // On Windows, fullscreen is owned by the WndProc subclass so its
            // `isFullscreen` flag stays in sync with WM_NCCALCSIZE / hit-test
            // logic. Tao's own fullscreen state would be FALSE in that case.
            if (Platform.Current == Platform.Windows && NativeTaoWindowsDecoBridge.isLoaded) {
                val hwnd = NativeTaoBridge.nativeHwndHandle(handle)
                if (hwnd != 0L) return NativeTaoWindowsDecoBridge.nativeIsFullscreen(hwnd)
            }
            return NativeTaoBridge.nativeIsFullscreen(handle)
        }

    public fun setMaximized(maximized: Boolean) {
        NativeTaoBridge.nativeSetMaximized(handle, maximized)
    }

    public fun minimize() {
        NativeTaoBridge.nativeSetMinimized(handle, true)
    }

    public fun setMinimized(minimized: Boolean) {
        NativeTaoBridge.nativeSetMinimized(handle, minimized)
    }

    // Windows fullscreen toggle: invoked with (targetW, targetH, fullscreen)
    // BEFORE the geometry change, so the render pipeline can pre-lay-out at
    // the final size (nothing is presented). The synchronous
    // WM_WINDOWPOSCHANGED prepare inside nativeSetFullscreen then only has
    // to re-draw — fast enough to finish within the geometry change.
    private val fullscreenPrepareListeners = CopyOnWriteArrayList<(Int, Int, Boolean) -> Unit>()

    /**
     * Windows only: registers the fullscreen pre-layout hook, invoked with
     * the target client size and target state before the toggle's geometry
     * change.
     */
    public fun onFullscreenPrepare(block: (width: Int, height: Int, fullscreen: Boolean) -> Unit) {
        fullscreenPrepareListeners += block
    }

    /** Borderless fullscreen on the current monitor.
     *
     * On Windows we route through the WndProc subclass (saves WINDOWPLACEMENT,
     * synchronises the deco's `isFullscreen` flag, restores cleanly) — Tao's
     * own `set_fullscreen` doesn't coordinate with our custom WM_NCCALCSIZE
     * and leaves the maximize button + window position desynced after exit.
     * Other platforms use Tao's native path. */
    public fun setFullscreen(fullscreen: Boolean) {
        if (Platform.Current == Platform.Windows && NativeTaoWindowsDecoBridge.isLoaded) {
            val hwnd = NativeTaoBridge.nativeHwndHandle(handle)
            if (hwnd != 0L) {
                setFullscreenWindows(hwnd, fullscreen)
                return
            }
        }
        NativeTaoBridge.nativeSetFullscreen(handle, fullscreen)
    }

    private fun setFullscreenWindows(
        hwnd: Long,
        fullscreen: Boolean,
    ) {
        // Pre-layout is main-thread only: the prepare hook renders on this
        // stack, and the EGL context lives on the Tao loop thread. An
        // off-thread caller still gets a correct (if less atomic) toggle
        // via the async RESIZED event.
        if (Thread.currentThread() === TaoMainDispatcher.taoMainThread) {
            val t = NativeTaoWindowsDecoBridge.nativeGetFullscreenTargetSize(hwnd, fullscreen)
            if (t != null && t.size == 2 && t.all { it > 0 }) {
                fullscreenPrepareListeners.forEach { it.invoke(t[0], t[1], fullscreen) }
            }
        }
        NativeTaoWindowsDecoBridge.nativeSetFullscreen(hwnd, fullscreen)
    }

    /**
     * Pins the window above every other window — Windows `HWND_TOPMOST`, macOS
     * `NSFloatingWindowLevel`, Linux `gtk_window_set_keep_above`
     * (`_NET_WM_STATE_ABOVE`; X11/XWayland only, native Wayland has no
     * client-side stacking protocol and logs a warning).
     *
     * Mutually exclusive with [setAlwaysOnBottom]: the last call wins.
     */
    public fun setAlwaysOnTop(alwaysOnTop: Boolean) {
        if (alwaysOnTopRequested == alwaysOnTop) return
        if (alwaysOnTop) {
            warnIfNativeWayland(
                "alwaysOnTop",
                "Wayland has no client-side stacking protocol (xdg-shell exposes none and " +
                    "Mutter rejects wlr-layer-shell), so gtk_window_set_keep_above is ignored.",
            )
            setAlwaysOnBottom(false)
        }
        alwaysOnTopRequested = alwaysOnTop
        NativeTaoBridge.nativeSetAlwaysOnTop(handle, alwaysOnTop)
        // Windows: also apply the z-order directly and synchronously. The tao
        // path above only updates its WindowFlags cache and posts an async
        // SetWindowPos on a cache diff, which can lose the race against style
        // rewrites (#631) — and once the cache and reality disagree, the tao
        // path never repairs it.
        applyTopmostDirect(alwaysOnTop)
    }

    /**
     * Re-applies the requested topmost z-order when it is set — the repair
     * half of issue #631. Windows style rewrites (a DWM backdrop switch, the
     * fullscreen toggle's `HWND_NOTOPMOST`, a size apply racing tao's async
     * z-order `SetWindowPos`) can silently drop `WS_EX_TOPMOST` while both
     * tao's flag cache and [alwaysOnTopRequested] still say `true`, so the
     * regular [setAlwaysOnTop] dedup never repairs it. Idempotent and cheap
     * when the z-order already matches; no-op off Windows.
     */
    internal fun reassertAlwaysOnTop() {
        if (alwaysOnTopRequested) applyTopmostDirect(true)
    }

    private fun applyTopmostDirect(topmost: Boolean) {
        if (Platform.Current != Platform.Windows || !NativeTaoWindowsDecoBridge.isLoaded) return
        val hwnd = NativeTaoBridge.nativeHwndHandle(handle)
        if (hwnd != 0L) NativeTaoWindowsDecoBridge.nativeApplyTopmost(hwnd, topmost)
    }

    /**
     * Pins the window below every other window — Windows `HWND_BOTTOM`, macOS
     * `NSWindowLevel.BelowNormal`, Linux `gtk_window_set_keep_below`
     * (`_NET_WM_STATE_BELOW`; X11/XWayland only, same Wayland caveat as
     * [setAlwaysOnTop]). For wallpaper-level overlays: a desktop widget, a
     * watermark that must never cover the app in front of it.
     *
     * Mutually exclusive with [setAlwaysOnTop]: the last call wins.
     *
     * Below-stacking is not the same thing as being part of the desktop — the
     * window still appears in the taskbar and in Alt+Tab (pair with
     * `hiddenFromDock` to drop those) and, on Wayland, a surface genuinely glued
     * to the wallpaper needs `wlr-layer-shell`, which Tao does not support.
     */
    public fun setAlwaysOnBottom(alwaysOnBottom: Boolean) {
        if (alwaysOnBottomRequested == alwaysOnBottom) return
        if (alwaysOnBottom) {
            warnIfNativeWayland(
                "alwaysOnBottom",
                "Wayland has no client-side stacking protocol (xdg-shell exposes none and " +
                    "Mutter rejects wlr-layer-shell), so gtk_window_set_keep_below is ignored.",
            )
            setAlwaysOnTop(false)
        }
        alwaysOnBottomRequested = alwaysOnBottom
        NativeTaoBridge.nativeSetAlwaysOnBottom(handle, alwaysOnBottom)
    }

    /**
     * Last requested stacking mode. Tao makes the two mutually exclusive only in
     * its `WindowBuilder`, not in the setters, so the pair is arbitrated here —
     * and clearing one must not be forwarded when it is already clear: on macOS
     * both `set_always_on_top(false)` and `set_always_on_bottom(false)` reset the
     * window level to `NSNormalWindowLevel`, so a redundant clear of one mode
     * would silently undo the other.
     */
    @Volatile
    private var alwaysOnTopRequested: Boolean = false

    @Volatile
    private var alwaysOnBottomRequested: Boolean = false

    public fun setFocusable(focusable: Boolean) {
        NativeTaoBridge.nativeSetFocusable(handle, focusable)
    }

    /**
     * Makes the window click-through: every pointer event falls through to
     * whatever sits below it (`WS_EX_TRANSPARENT | WS_EX_LAYERED` on Windows,
     * `NSWindow.ignoresMouseEvents` on macOS, an empty GDK input region on
     * Linux). Pair with [setFocusable]`(false)` for passive overlays such as
     * watermarks or HUDs that must never intercept input.
     */
    public fun setIgnoreCursorEvents(ignore: Boolean) {
        ignoreCursorEvents = ignore
        NativeTaoBridge.nativeSetIgnoreCursorEvents(handle, ignore)
    }

    /**
     * Last requested [setIgnoreCursorEvents] state, replayed by [show] — on
     * Linux the GDK input region is bound to the `GdkWindow` alive when it is
     * installed, and a window created hidden (every [DecoratedWindow], which
     * shows only after the first paint) swaps it on the way to its first map.
     * Windows and macOS keep the flag across the show, but replaying is a
     * plain style/flag write there too, so it stays unconditional.
     */
    @Volatile
    private var ignoreCursorEvents: Boolean = false

    /**
     * Shows the window on every desktop instead of only the one it was created
     * on — macOS `NSWindowCollectionBehaviorCanJoinAllSpaces`, Linux
     * `gtk_window_stick()` (X11/XWayland; native Wayland has no such
     * protocol).
     *
     * No-op on Windows, which needs none: a window excluded from the taskbar
     * (`hiddenFromDock`, i.e. `WS_EX_TOOLWINDOW`) is not tracked by the Virtual
     * Desktop Manager and is already visible on all desktops.
     *
     * macOS caveat: this joins every regular Space. Floating above *another*
     * app's full-screen Space additionally needs a window level above
     * `NSFloatingWindowLevel` (what [setAlwaysOnTop] maps to), which Tao does
     * not expose.
     */
    public fun setVisibleOnAllWorkspaces(visible: Boolean) {
        if (visible) {
            warnIfNativeWayland(
                "visibleOnAllWorkspaces",
                "Wayland has no client-side workspace protocol, so gtk_window_stick is ignored.",
            )
        }
        NativeTaoBridge.nativeSetVisibleOnAllWorkspaces(handle, visible)
    }

    /**
     * Logs once per window and per [feature] when this window's surface is a
     * native Wayland one, where several window-management features are simply
     * absent from the protocol. The check is per-window (the surface kind
     * reported by the native side), not a process-wide env sniff.
     */
    private fun warnIfNativeWayland(
        feature: String,
        detail: String,
    ) {
        if (!isNativeWaylandSurface || !waylandWarnings.add(feature)) return
        waylandLogger.warning(
            "$feature has no effect on native Wayland: $detail " +
                "Run with NUCLEUS_TAO_LINUX_RENDERER=x11 (XWayland) if the app needs it.",
        )
    }

    /**
     * `true` when this window is backed by a native Wayland surface, `false`
     * on X11/XWayland and on every other platform.
     *
     * Per-window, read from the native surface rather than the environment:
     * a window opened with `forceX11` reports `false` inside an app whose other
     * windows are Wayland. Only meaningful once the native window exists (after
     * `WINDOW_READY`).
     */
    public val isNativeWaylandSurface: Boolean
        get() {
            if (Platform.Current != Platform.Linux || !NativeTaoBridge.isLoaded) return false
            val handles = NativeTaoBridge.nativeLinuxHandles(handle) ?: return false
            return handles.isNotEmpty() && handles[0] == WAYLAND_HANDLE_KIND
        }

    /** Features already reported through [warnIfNativeWayland] for this window. */
    private val waylandWarnings = ConcurrentHashMap.newKeySet<String>()

    /** Logical pixels. Pass `null` to clear the minimum. */
    public fun setMinimumSize(
        widthDp: Double?,
        heightDp: Double?,
    ) {
        val w = widthDp ?: -1.0
        val h = heightDp ?: -1.0
        NativeTaoBridge.nativeSetMinInnerSize(handle, w, h)
    }

    /** [pixels] must be row-major premultiplied RGBA. Empty array clears. */
    public fun setIcon(
        width: Int,
        height: Int,
        pixels: ByteArray,
    ) {
        NativeTaoBridge.nativeSetWindowIcon(handle, width, height, pixels)
    }

    /** Logical pixels (matches [TaoApplication.openWindow]'s `width`/`height`). */
    public fun setInnerSize(
        widthDp: Double,
        heightDp: Double,
    ) {
        NativeTaoBridge.nativeSetInnerSize(handle, widthDp, heightDp)
    }

    /**
     * Logical pixels. Top-left of the outer (decoration-inclusive) window.
     *
     * **Linux popup overlays** (`isPopup`, `openWindow(popupOf = …)`):
     * - On **X11** the coordinates are root/screen space (override-redirect).
     * - On **native Wayland** they are **parent content-area** coordinates.
     *   The hidden-titlebar CSD puts the parent surface origin at the theme
     *   shadow margin while Compose's content (and content-relative pointer
     *   samples) live at GTK's content origin. This method adds that content
     *   origin before `wl_subsurface.set_position`, so callers — drag ghosts,
     *   in-scene popup layers — can keep working in content space. Zero once
     *   GTK collapses the margins (maximized / fullscreen / tiled).
     */
    public fun setOuterPosition(
        xDp: Double,
        yDp: Double,
    ) {
        var x = xDp
        var y = yDp
        // Wayland popup subsurface: content-area → parent-surface coords.
        // Detect the parent's backend (not env vars) so XWayland stays clean.
        if (isPopup && popupParentHandle != 0L && parentIsNativeWayland()) {
            val packed = NativeTaoBridge.nativeLinuxContentOrigin(popupParentHandle)
            // Packed as (x << 32) | (y & 0xffff_ffff) in logical GTK units.
            x += (packed shr 32).toInt()
            y += packed.toInt()
        }
        NativeTaoBridge.nativeSetOuterPosition(handle, x, y)
    }

    /** `true` when the popup parent is a native Wayland surface (kind == 2). */
    private fun parentIsNativeWayland(): Boolean {
        if (Platform.Current != Platform.Linux || !NativeTaoBridge.isLoaded) return false
        val handles = NativeTaoBridge.nativeLinuxHandles(popupParentHandle) ?: return false
        return handles.isNotEmpty() && handles[0] == WAYLAND_HANDLE_KIND
    }

    /**
     * Parent window when this is a Linux popup overlay, or `null`. Used by
     * [DecoratedWindow] Absolute positioning to convert screen-style coords
     * (parent outer + content-relative) into the content-area space
     * [setOuterPosition] expects on Wayland.
     */
    internal val popupParent: TaoWindow?
        get() = if (popupParentHandle != 0L) TaoApplication.lookup(popupParentHandle) else null

    /** Multi-cast: fires on every native window move. [xPx]/[yPx] are physical pixels. */
    public fun onMoved(block: (xPx: Int, yPx: Int) -> Unit) {
        movedListeners += block
    }

    private fun setStartupBackgroundEraseEnabled(enabled: Boolean) {
        if (Platform.Current != Platform.Windows || !NativeTaoWindowsDecoBridge.isLoaded) return
        val hwnd = NativeTaoBridge.nativeHwndHandle(handle)
        if (hwnd != 0L) NativeTaoWindowsDecoBridge.nativeSetStartupBackgroundEraseEnabled(hwnd, enabled)
    }

    /**
     * Invoked synchronously on every [show] call, before the native visibility
     * flip. The Windows scene host uses it to force the next present: DWM does
     * not reliably retain a pre-show swap once ShowWindow composites the
     * window, so the redraw that follows a show must reach eglSwapBuffers even
     * when the scene content itself is unchanged (clean frames skip the
     * present otherwise — see TaoSceneBundle.visualDirty).
     */
    internal var showHook: (() -> Unit)? = null

    public fun show() {
        startupEraseActive = true
        setStartupBackgroundEraseEnabled(true)
        showHook?.invoke()
        NativeTaoBridge.nativeSetVisible(handle, true)
        // Queued behind the show above (both ride the same event loop), so the
        // click-through state lands on the mapped window — see
        // [ignoreCursorEvents].
        if (ignoreCursorEvents) NativeTaoBridge.nativeSetIgnoreCursorEvents(handle, true)
        // The native surface exists by now, so this is the first point where an
        // unhonoured [requestedX11] can be reported.
        if (requestedX11 && isNativeWaylandSurface && waylandWarnings.add("forceX11")) {
            waylandLogger.warning(
                "forceX11 could not give this window an X11 surface — no X server on DISPLAY " +
                    "(no XWayland in this session?). It stays on Wayland, where stacking, " +
                    "positioning and workspace stickiness are unavailable.",
            )
        }
    }

    public fun hide() {
        NativeTaoBridge.nativeSetVisible(handle, false)
    }

    /** Raises the window, restores it if minimized, and gives it keyboard focus. */
    public fun focus() {
        NativeTaoBridge.nativeFocus(handle)
    }

    /**
     * Fires once, right after the NSWindow is created. The NSView pointer is
     * already valid; the window may still be hidden if it was created with
     * `visible = false`. Use this to attach the rendering pipeline and render
     * the first frame **before** calling [show], so the window appears with
     * content already drawn.
     */
    public fun onWindowReady(block: (width: Int, height: Int) -> Unit) {
        readyListener = block
    }

    /** Multi-cast: every call adds a listener; all of them fire on each resize. */
    public fun onResized(block: (width: Int, height: Int) -> Unit) {
        resizedListeners += block
    }

    public fun onScaleFactorChanged(block: (scale: Float) -> Unit) {
        scaleFactorListener = block
    }

    public fun onCloseRequested(block: () -> Unit) {
        closeRequestedListener = block
    }

    /**
     * Host / probe hook: present the opaque close frame before [requestClose]
     * destroys the window. Multi-cast — the Windows DecoratedWindow host
     * registers first; e2e probes may append. See [requestClose].
     */
    internal fun onPrepareClose(block: () -> Unit) {
        prepareCloseListeners += block
    }

    /** Multi-cast: every call adds a listener; all of them fire when the window is destroyed. */
    public fun onDestroyed(block: () -> Unit) {
        destroyedListeners += block
    }

    public fun onRedrawRequested(block: () -> Unit) {
        redrawListener = block
    }

    /** Multi-cast: every call adds a listener; all of them fire on each focus change. */
    public fun onFocusChanged(block: (focused: Boolean) -> Unit) {
        focusListeners += block
    }

    /**
     * Multi-cast: fires whenever the window's minimized (iconified) state flips,
     * including OS-driven minimize (taskbar, Win+D, Dock, Cmd-M) and the
     * title-bar button.
     *
     * Wired on all three platforms: macOS (windowDidMiniaturize/Deminiaturize),
     * Windows (WM_SIZE hook), and Linux — X11 via the GTK window-state-event,
     * Wayland via an app-driven synthesis hack (our minimize button /
     * programmatic only; the protocol reports no iconified state).
     */
    public fun onMinimizedChanged(block: (minimized: Boolean) -> Unit) {
        minimizedListeners += block
    }

    /**
     * Linux only. Fires synchronously on the event-loop thread right before
     * the GTK window is hidden — the host must suspend EGL rendering before
     * Wayland's parent `wl_surface` is destroyed (see [TaoEventCode.WILL_HIDE]).
     */
    public fun onWillHide(block: () -> Unit) {
        willHideListener = block
    }

    /**
     * Linux only. Fires synchronously right after the GTK window is shown
     * again, once the GDK surface exists — the host may re-attach EGL.
     */
    public fun onShown(block: () -> Unit) {
        shownListener = block
    }

    /**
     * Windows only. Fires on the event-loop thread when the OS modal
     * resize/move loop starts (`true`, WM_ENTERSIZEMOVE) and ends (`false`,
     * WM_EXITSIZEMOVE). The host drops VSync while active so a border drag
     * isn't throttled to the display refresh. No source on macOS / Linux.
     */
    public fun onSizeMoveChanged(block: (active: Boolean) -> Unit) {
        sizeMoveListener = block
    }

    public fun onPointerMoved(block: (xFixed: Int, yFixed: Int) -> Unit) {
        pointerMoveListener = block
    }

    public fun onPointerExited(block: () -> Unit) {
        pointerExitedListener = block
    }

    public fun onPointerButton(block: (button: Int, pressed: Boolean) -> Unit) {
        pointerButtonListener = block
    }

    /**
     * Mouse-wheel / trackpad scroll. Deltas are shaped like AWT's
     * `MouseWheelEvent.preciseWheelRotation`; the event also carries the AWT
     * `scrollAmount` metadata Compose Desktop reads when calculating platform
     * scroll distance.
     */
    internal fun onPointerScroll(block: (TaoPointerScrollEvent) -> Unit) {
        pointerScrollListener = block
    }

    public fun onKeyEvent(listener: KeyEventListener) {
        keyListener = listener
    }

    /**
     * Trackpad gesture stream — see [TrackpadGestureListener]. macOS/Linux emit
     * magnify/rotate/smart-magnify; Windows emits magnify only (Ctrl+wheel /
     * precision-touchpad pinch). No native source on other configurations.
     */
    public fun onTrackpadGesture(listener: TrackpadGestureListener) {
        trackpadGestureListener = listener
    }

    /** Windows only — see [TouchInputListener]. No-op on Linux / macOS. */
    public fun onTouchInput(listener: TouchInputListener) {
        touchInputListener = listener
    }

    internal fun dispatchTouchInput(
        phase: Int,
        id: Long,
        xFixed: Int,
        yFixed: Int,
        forceFixed: Int,
    ) {
        touchInputListener?.onTouch(phase, id, xFixed, yFixed, forceFixed)
    }

    internal fun dispatchTrackpadGesture(
        kind: Int,
        phase: Int,
        xFixed: Int,
        yFixed: Int,
        valueFixed: Int,
    ) {
        trackpadGestureListener?.onGesture(kind, phase, xFixed, yFixed, valueFixed)
    }

    /**
     * macOS trackpad scroll gesture (#654) — see
     * [NativeTaoBridge.EventCallback.onScrollGesture]. Shaped exactly like
     * [TaoEventCode.SCROLL_PIXEL] (AWT `preciseWheelRotation`, so one unit is
     * `10.dp` of pan for Compose) with the gesture [phase] attached; the
     * scene host turns the stream into Compose Pan events.
     */
    internal fun dispatchScrollGesture(
        phaseWire: Int,
        dxFixed: Int,
        dyFixed: Int,
    ) {
        // A code this build does not know degrades to a plain precise scroll
        // rather than a pan step the router cannot place.
        val phase = TaoScrollGesturePhase.fromWire(phaseWire)
        pointerScrollListener?.invoke(preciseScrollEvent(dxFixed, dyFixed, gesturePhase = phase))
    }

    /**
     * AWT's macOS NSEvent → MouseWheelEvent conversion: `preciseWheelRotation
     * = -scrollingDelta / 10`, no display scale (#652 / #653). The wire carries
     * LOGICAL AppKit points × [SCROLL_FIXED_SCALE]; tao (and AppKit) count
     * positive as "content moves down / right", AWT as "scroll down / right",
     * hence the negation on both axes.
     */
    private fun preciseScrollEvent(
        dxFixed: Int,
        dyFixed: Int,
        gesturePhase: TaoScrollGesturePhase?,
    ) = TaoPointerScrollEvent(
        dxAwt = -(dxFixed / SCROLL_FIXED_SCALE) / AWT_PIXEL_TO_ROTATION,
        dyAwt = -(dyFixed / SCROLL_FIXED_SCALE) / AWT_PIXEL_TO_ROTATION,
        scrollAmount = MACOS_AWT_SCROLL_AMOUNT,
        gesturePhase = gesturePhase,
    )

    internal fun dispatchKey(
        type: Int,
        vkCode: Int,
        keyLocation: Int,
        modifiers: Int,
        codePoint: Int,
    ) {
        keyListener?.onKey(type, vkCode, keyLocation, modifiers, codePoint)
    }

    /**
     * macOS replacement commit — `insertText:` with a valid
     * `replacementRange` (UTF-16, document-absolute) outside a composition.
     * See [NativeTaoBridge.EventCallback.onImeReplaceCommit].
     */
    @Volatile
    internal var imeReplaceCommit: ((String, Long, Long) -> Unit)? = null

    internal fun dispatchImeReplaceCommit(
        text: String,
        replacementStart: Long,
        replacementLength: Long,
    ) {
        imeReplaceCommit?.invoke(text, replacementStart, replacementLength)
    }

    /**
     * macOS IME composition update (marked text). Empty [String] cancels.
     * See [NativeTaoBridge.EventCallback.onImePreedit].
     */
    @Volatile
    internal var imePreedit: ((String) -> Unit)? = null

    internal fun dispatchImePreedit(text: String) {
        imePreedit?.invoke(text)
    }

    /**
     * macOS IME composition commit. See [NativeTaoBridge.EventCallback.onImeCommit].
     */
    @Volatile
    internal var imeCommit: ((String) -> Unit)? = null

    internal fun dispatchImeCommit(text: String) {
        imeCommit?.invoke(text)
    }

    @Suppress("CyclomaticComplexMethod")
    internal fun dispatch(
        code: Int,
        a: Int,
        b: Int,
    ) {
        when (code) {
            TaoEventCode.WINDOW_READY -> readyListener?.invoke(a, b)
            TaoEventCode.RESIZED -> {
                // Win32 emits WM_SIZE/SIZE_MINIMIZED as 0x0. Keep resize
                // listeners on the last real content size while minimized.
                if (a <= 0 || b <= 0) return
                // A size apply can drop WS_EX_TOPMOST (#631) — repair it
                // before app code observes the resize. Idempotent no-op when
                // the z-order is already correct or the flag is off.
                reassertAlwaysOnTop()
                resizedListeners.forEach { it.invoke(a, b) }
            }
            TaoEventCode.MOVED -> movedListeners.forEach { it.invoke(a, b) }
            TaoEventCode.SCALE_FACTOR_CHANGED -> scaleFactorListener?.invoke(a / 1000f)
            TaoEventCode.CLOSE_REQUESTED -> closeRequestedListener?.invoke()
            TaoEventCode.DESTROYED -> {
                destroyedListeners.forEach { it.invoke() }
                TaoApplication.remove(handle)
            }
            TaoEventCode.REDRAW_REQUESTED -> {
                // Clear *before* invoking — if the listener (which renders) posts
                // another invalidate via `requestRedraw`, the next frame must go
                // through. Setting after would drop legitimate follow-up frames.
                redrawPending.set(false)
                redrawListener?.invoke()
                // First real frame is now present in the visible surface; stop
                // the themed startup erase so it never flickers during resize.
                if (startupEraseActive) {
                    startupEraseActive = false
                    setStartupBackgroundEraseEnabled(false)
                }
            }
            TaoEventCode.FOCUSED -> {
                // A redraw request issued while this window was occluded by a
                // modal child (e.g. a DecoratedDialog) can be dropped by the OS
                // with no matching REDRAW_REQUESTED, latching `redrawPending`
                // true and silently suppressing every future frame until a
                // manual resize. Regaining focus means we are foreground again:
                // clear the latch and re-issue so a lost frame can't wedge
                // rendering. No frame is lost — a genuinely in-flight redraw
                // just yields one extra, idempotent request.
                redrawPending.set(false)
                requestRedraw()
                focusListeners.forEach { it.invoke(true) }
            }
            TaoEventCode.UNFOCUSED -> focusListeners.forEach { it.invoke(false) }
            TaoEventCode.MINIMIZED -> {
                val minimized = a != 0
                isMinimized = minimized
                // On restore, re-kick the render loop. While minimized the scene
                // host gates frames out before the frame clock ticks, so Compose
                // animations are parked and nothing re-arms a redraw on its own.
                if (!minimized) requestRedraw()
                minimizedListeners.forEach { it.invoke(minimized) }
            }
            TaoEventCode.CURSOR_MOVED -> pointerMoveListener?.invoke(a, b)
            TaoEventCode.CURSOR_LEFT -> pointerExitedListener?.invoke()
            TaoEventCode.MOUSE_DOWN -> pointerButtonListener?.invoke(a, true)
            TaoEventCode.MOUSE_UP -> pointerButtonListener?.invoke(a, false)
            TaoEventCode.MODIFIERS_CHANGED -> modifierState = a
            TaoEventCode.WILL_HIDE -> willHideListener?.invoke()
            TaoEventCode.SHOWN -> shownListener?.invoke()
            TaoEventCode.SIZE_MOVE -> sizeMoveListener?.invoke(a != 0)
            TaoEventCode.SCROLL_LINE -> {
                // tao (and AppKit) count positive as "content moves down /
                // right"; AWT counts positive as "scroll down / right", hence
                // the negation on both axes.
                // AWT sends the wheel rotation as scrollDelta and leaves the
                // platform line-count policy in MouseWheelEvent.scrollAmount.
                // The Windows backend emits the raw notch count (1.0 per notch,
                // fractional for precision touchpads) — it deliberately does NOT
                // apply SPI_GETWHEELSCROLLLINES, so the line-count policy is
                // carried in [platformLineScrollAmount] and the notch→pixel
                // mapping is left to the downstream ScrollConfig. macOS AWT
                // reports scrollAmount=1; Linux mirrors AWT's common
                // three-lines-per-notch default here.
                val dx = -(a / SCROLL_FIXED_SCALE)
                val dy = -(b / SCROLL_FIXED_SCALE)
                pointerScrollListener?.invoke(
                    TaoPointerScrollEvent(
                        dxAwt = dx,
                        dyAwt = dy,
                        scrollAmount = platformLineScrollAmount,
                    ),
                )
            }
            TaoEventCode.SCROLL_PIXEL -> {
                // Precise scroll outside a gesture (smooth-scroll mice); see
                // [preciseScrollEvent] for the AWT shaping.
                pointerScrollListener?.invoke(preciseScrollEvent(a, b, gesturePhase = null))
            }
            // KEY_DOWN / KEY_UP: routed in Phase 2b (no logical-key encoding yet)
        }
    }

    private companion object {
        const val SCROLL_FIXED_SCALE: Float = 100f
        const val LINUX_AWT_SCROLL_AMOUNT_DEFAULT: Int = 3

        // ABI: a `const val` in a private companion still compiles to a public
        // static on TaoWindow, and these two are part of the validated 2.4.x
        // surface (api/decorated-window-tao.api). Aliases of the shared
        // definitions in event/MacOsWheelDelta.kt so they cannot diverge.
        const val AWT_PIXEL_TO_ROTATION: Float = SHARED_AWT_PIXEL_TO_ROTATION
        const val MACOS_AWT_SCROLL_AMOUNT: Int = SHARED_MACOS_AWT_SCROLL_AMOUNT
        const val WINDOWS_TOUCH_DRAG_THRESHOLD_PX: Int = 16

        val platformLineScrollAmount: Int
            get() =
                when (Platform.Current) {
                    Platform.Linux -> LINUX_AWT_SCROLL_AMOUNT_DEFAULT
                    else -> MACOS_AWT_SCROLL_AMOUNT
                }

        /** `nativeLinuxHandles` slot 0: 1 = Xlib, 2 = Wayland. */
        const val WAYLAND_HANDLE_KIND: Long = 2L

        val waylandLogger: Logger = Logger.getLogger("dev.nucleusframework.window.tao.wayland")
    }
}

/**
 * One wheel / trackpad scroll step, shaped like AWT's `MouseWheelEvent`:
 * [dxAwt] / [dyAwt] are `preciseWheelRotation` (positive = scroll down /
 * right), [scrollAmount] the platform line-count policy Compose Desktop reads.
 * [gesturePhase] is the [TaoScrollGesturePhase] of a macOS trackpad gesture
 * step, or `null` for a wheel notch / phase-less device — gesture steps
 * become Compose Pan events, the rest ordinary Scroll events.
 */
internal data class TaoPointerScrollEvent(
    val dxAwt: Float,
    val dyAwt: Float,
    val scrollAmount: Int,
    val gesturePhase: TaoScrollGesturePhase? = null,
)

private data class WindowsTitleBarTouchDrag(
    val touchId: Long,
    val hwnd: Long,
    var startScreenX: Int,
    var startScreenY: Int,
    var startOuterX: Long,
    var startOuterY: Long,
    var wasMaximized: Boolean,
    var prepared: Boolean,
    var lastScreenX: Int,
    var lastScreenY: Int,
)
