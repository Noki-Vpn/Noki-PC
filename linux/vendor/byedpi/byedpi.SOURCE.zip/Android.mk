LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE := noki_byedpi
LOCAL_SRC_FILES := packets.c main.c conev.c proxy.c desync.c mpool.c extend.c noki.c
LOCAL_CFLAGS := -std=c99 -O2 -D_DEFAULT_SOURCE -D_GNU_SOURCE -Wall -Wextra -Wno-unused-parameter -Wno-unused-function
LOCAL_LDFLAGS := -Wl,-z,relro,-z,now
include $(BUILD_EXECUTABLE)
