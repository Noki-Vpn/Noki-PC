#include "noki.h"
#include "params.h"
#include "extend.h"

#include <errno.h>
#include <limits.h>
#include <signal.h>
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <windows.h>
#define close closesocket
#else
#include <fcntl.h>
#include <net/if.h>
#include <netinet/tcp.h>
#include <sys/prctl.h>
#include <sys/time.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>
#endif

static const char *interface_name, *source_ip, *listen_path;
static const char *profile;
static unsigned long parent_pid, socket_mark;
static int android_profile;
static volatile sig_atomic_t stop_requested;
static uint64_t last_parent_check;
#ifdef _WIN32
static HANDLE parent_handle;
#else
static unsigned long long parent_start;
#endif

static int fail(const char *message)
{
#ifdef _WIN32
    fprintf(stderr, "NOKI_ERROR %s errno=%d winsock=%d\n", message, errno, WSAGetLastError());
#else
    fprintf(stderr, "NOKI_ERROR %s errno=%d\n", message, errno);
#endif
    return -1;
}

static int md5_probe(void)
{
#if defined(__linux__) && defined(TCP_MD5SIG)
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return -1;
    struct tcp_md5sig key = {0};
    struct sockaddr_in *peer = (struct sockaddr_in *)&key.tcpm_addr;
    peer->sin_family = AF_INET;
    peer->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    key.tcpm_keylen = 5;
    int result = setsockopt(fd, IPPROTO_TCP, TCP_MD5SIG, &key, sizeof(key));
    int error = errno;
    if (result == 0) {
        key.tcpm_keylen = 0;
        result = setsockopt(fd, IPPROTO_TCP, TCP_MD5SIG, &key, sizeof(key));
        error = errno;
    }
    close(fd);
    errno = error;
    if (result == 0) return 1;
    if (error == ENOPROTOOPT || error == EOPNOTSUPP || error == ENOSYS ||
        error == ENOENT || error == EPERM || error == EACCES) return 0;
    return -1;
#else
    errno = ENOPROTOOPT;
    return 0;
#endif
}

static unsigned long number(const char *value)
{
    char *end;
    errno = 0;
    unsigned long result = strtoul(value, &end, 10);
    if (errno || !*value || *end || *value == '-' || result > INT_MAX) return 0;
    return result;
}

int noki_parse_args(int *argc, char ***argv)
{
    if (*argc > 120) return fail("too-many-arguments");
    char **filtered = calloc(128, sizeof(char *));
    if (!filtered) return fail("arguments-allocation");
    int count = 0;
    filtered[count++] = (*argv)[0];
    for (int i = 1; i < *argc; i++) {
        const char *arg = (*argv)[i];
        if (!strcmp(arg, "--noki-capabilities")) {
            int supported = md5_probe();
            free(filtered);
            if (supported < 0) return fail("md5sig-probe");
            printf("NOKI_CAPABILITIES version=0.17.3 md5sig=%d\n", supported);
            return 1;
        }
        if (!strcmp(arg, "--noki-android-profile")) { android_profile = 1; continue; }
        const char **text = NULL;
        unsigned long *integer = NULL;
        if (!strcmp(arg, "--noki-interface")) text = &interface_name;
        else if (!strcmp(arg, "--noki-source")) text = &source_ip;
        else if (!strcmp(arg, "--noki-listen-path")) text = &listen_path;
        else if (!strcmp(arg, "--noki-parent")) integer = &parent_pid;
        else if (!strcmp(arg, "--noki-mark")) integer = &socket_mark;
        else if (!strncmp(arg, "--noki-", 7)) { free(filtered); return fail("unknown-noki-option"); }
        else { filtered[count++] = (*argv)[i]; continue; }
        if (++i >= *argc) { free(filtered); return fail("missing-noki-option-value"); }
        if (text) {
            if (*text || !*(*argv)[i]) { free(filtered); return fail("invalid-noki-option"); }
            *text = (*argv)[i];
        } else {
            if (*integer || !(*integer = number((*argv)[i]))) { free(filtered); return fail("invalid-noki-number"); }
        }
    }
    if (android_profile) {
#ifdef __ANDROID__
        int supported = md5_probe();
        if (supported < 0) { free(filtered); return fail("md5sig-probe"); }
        if (supported) {
            filtered[count++] = "--fake"; filtered[count++] = "-1"; filtered[count++] = "--md5sig";
            profile = "linux-md5sig";
        } else {
            fprintf(stderr, "NOKI_PROFILE md5sig-unavailable errno=%d fallback=disorder-1\n", errno);
            filtered[count++] = "--disorder"; filtered[count++] = "1";
            profile = "android-disorder-md5sig-unavailable";
        }
#else
        free(filtered); return fail("android-profile-on-other-platform");
#endif
    }
    *argc = count; *argv = filtered;
    return 0;
}

#ifndef _WIN32
static int parent_identity(unsigned long long *started)
{
    char path[64], buffer[4096];
    snprintf(path, sizeof(path), "/proc/%lu/stat", parent_pid);
    FILE *file = fopen(path, "r");
    if (!file) return 0;
    char *line = fgets(buffer, sizeof(buffer), file);
    fclose(file);
    if (!line) return 0;
    char *value = strrchr(buffer, ')');
    if (!value || value[1] != ' ' || value[2] == 'Z' || value[2] == 'X') return 0;
    value += 2;
    for (int field = 3; field < 22; field++) {
        value = strchr(value, ' ');
        if (!value) return 0;
        value++;
    }
    char *end;
    *started = strtoull(value, &end, 10);
    return end != value && *started != 0;
}

static int ipc(const char *path, unsigned char request, int outgoing, int *incoming)
{
    struct sockaddr_un address = {0};
    address.sun_family = AF_UNIX;
    size_t length = strlen(path);
    if (!length || length >= sizeof(address.sun_path)) { errno = ENAMETOOLONG; return fail("protect-path"); }
    memcpy(address.sun_path, path, length + 1);
    socklen_t size = (socklen_t)(offsetof(struct sockaddr_un, sun_path) + length + 1);
    if (*path == '@') { address.sun_path[0] = 0; size--; }
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) return fail("protect-socket");
    struct timeval timeout = {.tv_sec = 1};
    if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) ||
        setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) ||
        connect(fd, (struct sockaddr *)&address, size)) { close(fd); return fail("protect-connect"); }
    struct ucred peer;
    socklen_t peer_size = sizeof(peer);
    if (getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &peer, &peer_size) || peer.uid != geteuid()) {
        close(fd); errno = EACCES; return fail("protect-peer");
    }
    char control[CMSG_SPACE(sizeof(int) * 4)] = {0};
    struct iovec vector = {.iov_base = &request, .iov_len = 1};
    struct msghdr message = {.msg_iov = &vector, .msg_iovlen = 1};
    if (outgoing >= 0) {
        message.msg_control = control; message.msg_controllen = CMSG_SPACE(sizeof(int));
        struct cmsghdr *header = CMSG_FIRSTHDR(&message);
        header->cmsg_level = SOL_SOCKET; header->cmsg_type = SCM_RIGHTS; header->cmsg_len = CMSG_LEN(sizeof(int));
        memcpy(CMSG_DATA(header), &outgoing, sizeof(int));
    }
    if (sendmsg(fd, &message, 0) != 1) { close(fd); return fail("protect-send"); }
    memset(control, 0, sizeof(control));
    unsigned char ack = 255;
    vector.iov_base = &ack;
    message.msg_control = control; message.msg_controllen = sizeof(control); message.msg_flags = 0;
    ssize_t received = recvmsg(fd, &message, 0);
    int result = -1, count = 0;
    for (struct cmsghdr *header = CMSG_FIRSTHDR(&message); header; header = CMSG_NXTHDR(&message, header)) {
        if (header->cmsg_level != SOL_SOCKET || header->cmsg_type != SCM_RIGHTS || header->cmsg_len < CMSG_LEN(0)) continue;
        size_t descriptors = (header->cmsg_len - CMSG_LEN(0)) / sizeof(int);
        for (size_t i = 0; i < descriptors; i++) {
            int duplicate;
            memcpy(&duplicate, (char *)CMSG_DATA(header) + i * sizeof(int), sizeof(int));
            if (incoming && !count) result = duplicate; else close(duplicate);
            count++;
        }
    }
    close(fd);
    if (received != 1 || ack != 0 || (message.msg_flags & (MSG_CTRUNC | MSG_TRUNC)) || count != (incoming ? 1 : 0)) {
        if (result >= 0) close(result);
        errno = EACCES; return fail("protect-rejected");
    }
    if (incoming) *incoming = result;
    return 0;
}
#endif

int noki_protect_socket(int fd, const char *path)
{
#ifdef _WIN32
    (void)fd; (void)path;
    return fail("protect-path-on-windows");
#else
    return ipc(path, '1', fd, NULL);
#endif
}

int noki_socket_egress(int fd)
{
    if (!interface_name) return 0;
#ifdef _WIN32
    unsigned long index = number(interface_name);
    if (!index) return fail("physical-interface");
    DWORD network_index = htonl(index);
    if (setsockopt(fd, IPPROTO_IP, IP_UNICAST_IF, (const char *)&network_index, sizeof(network_index))) return fail("physical-interface-bind");
#else
    uint32_t mark = (uint32_t)socket_mark;
    if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, interface_name, strlen(interface_name) + 1) ||
        setsockopt(fd, SOL_SOCKET, SO_MARK, &mark, sizeof(mark))) return fail("physical-interface-mark");
#endif
    return 0;
}

int noki_configure(void)
{
    if (parent_pid <= 1 || params.resolve || params.udp || params.ipv6 || params.transparent || params.http_connect ||
        params.max_open != 4096 || params.laddr.sa.sa_family != AF_INET ||
        params.laddr.in.sin_addr.s_addr != htonl(INADDR_LOOPBACK) || params.baddr.sa.sa_family != AF_INET) return fail("unsafe-profile");
#ifdef _WIN32
    if (!interface_name || !source_ip || socket_mark || listen_path || params.protect_path || android_profile) return fail("windows-egress-options");
    if (params.dp->md5sig || params.dp->parts_n != 2 || params.dp->parts[0].m != DESYNC_DISORDER ||
        params.dp->parts[0].pos != 1 || params.dp->parts[1].m != DESYNC_FAKE || params.dp->parts[1].pos != -1) return fail("windows-desync-profile");
    parent_handle = OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, parent_pid);
    if (!parent_handle || WaitForSingleObject(parent_handle, 0) != WAIT_TIMEOUT) return fail("parent-unavailable");
    profile = "windows-disorder-fake";
#else
    if (!parent_identity(&parent_start)) return fail("parent-unavailable");
    if ((unsigned long)getppid() == parent_pid &&
        (prctl(PR_SET_PDEATHSIG, SIGKILL) || (unsigned long)getppid() != parent_pid)) return fail("parent-changed");
#ifdef __ANDROID__
    if (!android_profile || interface_name || source_ip || socket_mark || !params.protect_path ||
        !listen_path || strcmp(listen_path, params.protect_path)) return fail("android-egress-options");
    if (params.dp->parts_n != 1 ||
        (!strcmp(profile, "linux-md5sig") && (!params.dp->md5sig || params.dp->parts[0].m != DESYNC_FAKE || params.dp->parts[0].pos != -1)) ||
        (strcmp(profile, "linux-md5sig") && (params.dp->md5sig || params.dp->parts[0].m != DESYNC_DISORDER || params.dp->parts[0].pos != 1))) return fail("android-desync-profile");
#else
    if (android_profile || !interface_name || strlen(interface_name) >= IFNAMSIZ || !if_nametoindex(interface_name) ||
        !source_ip || socket_mark != 20047 || params.protect_path || listen_path) return fail("linux-egress-options");
    if (!params.dp->md5sig || params.dp->parts_n != 1 || params.dp->parts[0].m != DESYNC_FAKE ||
        params.dp->parts[0].pos != -1 || md5_probe() != 1) return fail("linux-md5sig-profile");
    profile = "linux-md5sig";
#endif
#endif
    if (source_ip && (inet_pton(AF_INET, source_ip, &params.baddr.in.sin_addr) != 1 ||
        params.baddr.in.sin_addr.s_addr == htonl(INADDR_ANY))) return fail("physical-source-ip");
    int probe = (int)socket(AF_INET, SOCK_STREAM, 0);
    if (probe < 0) return fail("egress-probe-socket");
    int valid = socket_mod(probe);
    if (!valid) valid = bind(probe, &params.baddr.sa, sizeof(params.baddr.in));
    close(probe);
    if (valid) return fail("egress-probe");
    return 0;
}

int noki_take_listener(void)
{
    if (!listen_path) return -2;
#ifdef _WIN32
    return fail("inherited-listener-on-windows");
#else
    int fd;
    if (ipc(listen_path, 2, -1, &fd)) return -1;
    struct sockaddr_in bound;
    socklen_t length = sizeof(bound);
    int accepting = 0;
    socklen_t option_length = sizeof(accepting);
    if (getsockname(fd, (struct sockaddr *)&bound, &length) || length != sizeof(bound) ||
        bound.sin_family != AF_INET || bound.sin_addr.s_addr != htonl(INADDR_LOOPBACK) ||
        bound.sin_port != params.laddr.in.sin_port ||
        getsockopt(fd, SOL_SOCKET, SO_ACCEPTCONN, &accepting, &option_length) || !accepting ||
        fcntl(fd, F_SETFL, O_NONBLOCK)) { close(fd); return fail("invalid-inherited-listener"); }
    return fd;
#endif
}

int noki_ready(int fd)
{
    struct sockaddr_in address;
    socklen_t size = sizeof(address);
    if (getsockname(fd, (struct sockaddr *)&address, &size) || address.sin_family != AF_INET ||
        address.sin_addr.s_addr != htonl(INADDR_LOOPBACK)) return fail("invalid-listener");
    printf("NOKI_READY port=%u profile=%s\n", (unsigned)ntohs(address.sin_port), profile);
    fflush(stdout);
    return 0;
}

void noki_request_stop(void) { stop_requested = 1; }

int noki_keep_running(void)
{
    if (stop_requested) return 0;
    uint64_t now;
#ifdef _WIN32
    now = GetTickCount64();
#else
    struct timespec time;
    clock_gettime(CLOCK_MONOTONIC, &time);
    now = (uint64_t)time.tv_sec * 1000 + time.tv_nsec / 1000000;
#endif
    if (last_parent_check && now - last_parent_check < 1000) return 1;
    last_parent_check = now;
#ifdef _WIN32
    return parent_handle && WaitForSingleObject(parent_handle, 0) == WAIT_TIMEOUT;
#else
    unsigned long long started;
    return parent_identity(&started) && started == parent_start;
#endif
}
